this is a random UwU player, for YT DM Vm also have iptv m3u function and playlist included. 

set in server menú YT DM Vm and also py for your flask python if some server that can't set connection because CORS

run server.py and replace in tube.js --> decoinserver(url) '/deco' for '{were are you server}/deco' and in  showServerMenu() --> '/show_deco' for '{were are you server}/show_deco'

and when you load and there are message "loading..." and nothing do, change server to 'py flask' and press search button 